<?php   
   session_start();
$num=$_REQUEST["num"];
$num=$_REQUEST["page"];
require_once("../lib/MYDB.php");
$pdo = db_connect();

try {
	$pdo->beginTransaction();
	$sql = "delete from phptest.qna where num = ?";
	$stmh = $pdo->prepare($sql);
	$stmh->bindValue(1,$num,PDO::PARAM_STR);
	$stmh->execute();
	$pdo->commit();
	header("Location:http://localhost/semina/qna/list.php?page=$page");
}
catch (Exception $ex) {
	$pdo->rollBack();
	print "오류: ".$Exception->getMessage();
}