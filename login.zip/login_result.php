<?php
session_start();

$id = $_REQUEST["id"];
$pw = $_REQUEST["pass"];

$str1 = strcmp($id, "admin");
$str2 = strcmp($pw, "123456");

if($id == "admin" && $pw == "123456"){
    $_SESSION["userid"]=$row["admin"];
    $_SESSION["name"]=$row["관리자"];
    $_SESSION["nick"]=$row["관리자"];
    $_SESSION["level"]=$row["1"];
    
    header("Location:http://localhost/semina/index.php");
    exit;
}
require_once("../lib/MYDB.php");
$pdo = db_connect();

try{
    $sql = "select * from phptest.member where id=?";
    $stmh = $pdo->prepare($sql);
    $stmh->bindValue(1,$id,PDO::PARAM_STR);
    $stmh->execute();
    
    $count = $stmh->rowCount();
} catch (PDOException $Exception) {
    print "오류: ".$Exception->getMessage();
}
$row=$stmh->fetch(PDO::FETCH_ASSOC);

if($count<1){  //일치하는 아이디가 없는 경우
    ?>
<script>
    alert("아이디가 틀립니다!");
    history.back(); //이전 페이지로 이동
</script>

<?php
} elseif($pw!=$row["pass"]){  //비밀번호가 같지 않을 때
    ?>

<script>
    alert("비밀번호가 틀립니다!");
    history.back();
    </script>
    <?php
} else{
    $_SESSION["userid"]=$row["id"];
    $_SESSION["name"]=$row["name"];
    $_SESSION["nick"]=$row["nick"];
    $_SESSION["level"]=$row["level"];
    
    header("Location:http://localhost/semina/index.php");
    exit;
}
?>